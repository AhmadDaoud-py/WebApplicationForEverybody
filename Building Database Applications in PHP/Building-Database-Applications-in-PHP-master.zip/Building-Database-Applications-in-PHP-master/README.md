# Building-Database-Applications-in-PHP

learning notes.

view the course: https://www.coursera.org/learn/database-applications-php